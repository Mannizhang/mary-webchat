Core web framework
==================

.. toctree::
   :maxdepth: 2

   web
   httpserver
   template
   escape
   locale
