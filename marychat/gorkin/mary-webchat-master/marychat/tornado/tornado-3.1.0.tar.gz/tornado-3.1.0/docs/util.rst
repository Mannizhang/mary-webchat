``tornado.util`` --- General-purpose utilities
==============================================

.. automodule:: tornado.util
    :members:
