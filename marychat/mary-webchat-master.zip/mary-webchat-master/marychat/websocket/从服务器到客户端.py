HTTP / 1.1
101
Switching
Protocols
Upgrade: websocket
Connection: Upgrade
Sec - WebSocket - Accept: s3pPLMBiTxaQ9kYGzzhZRbK + xOo =
Sec - WebSocket - Protocol: chat
