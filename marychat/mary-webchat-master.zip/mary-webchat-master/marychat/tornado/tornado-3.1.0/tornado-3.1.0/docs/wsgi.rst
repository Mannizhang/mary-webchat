``tornado.wsgi`` --- Interoperability with other Python frameworks and servers
==============================================================================

.. automodule:: tornado.wsgi

   WSGIApplication
   ---------------

   .. autoclass:: WSGIApplication
      :members:

   .. autoclass:: HTTPRequest
      :members:

   WSGIContainer
   -------------
  
   .. autoclass:: WSGIContainer
      :members:
